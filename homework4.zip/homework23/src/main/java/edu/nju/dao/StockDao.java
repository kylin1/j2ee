package edu.nju.dao;

import edu.nju.model.Stock;

import java.util.List;

public interface StockDao {

	public List find();
}
