package edu.nju.factory;

/**
 * Created by kylin on 26/12/2016.
 * All rights reserved.
 */
public class ServiceFactory {

//    public static IStudentService getStudentService() {
//        return StudentService.getInstance();
//    }
//
//    public static ICourseService getCourseService() {
//        return CourseService.getInstance();
//    }
//
//    public static ISelectionService getSelectionService() {
//        return SelectionService.getInstance();
//    }
//
//    public static StockManageService getStockManageService() {
//        return StockManageServiceImpl.getInstance();
//    }
}
